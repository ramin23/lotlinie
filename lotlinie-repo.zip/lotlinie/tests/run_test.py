"""End-to-End-Test der Lotlinie-App im Headless-Chrome (Samsung-Viewport)."""
from playwright.sync_api import sync_playwright
import json, re, os, sys

import subprocess, time, socket
def HERE_L(): return os.path.dirname(os.path.abspath(__file__)) or '.'
def free_port():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p
PORT = free_port()
SRV = subprocess.Popen(['python3','-m','http.server',str(PORT),'--bind','127.0.0.1'],
                       cwd=os.path.join(HERE_L(), '..'), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(0.8)
APP = f'http://127.0.0.1:{PORT}/index.html'
S = os.path.join(HERE_L(), 'shots'); os.makedirs(S, exist_ok=True)
LM = json.load(open(os.path.join(HERE_L(), 'landmarks.json')))
ORDER_LAT = ['tragus','c7','acromion','trochanter','knee','malleolus']
ORDER_FRO = ['eyeL','eyeR','shL','shR','hipL','hipR','ankL','ankR']
IMG_W = 800.0
errors, results = [], []
def HERE_L(): return os.path.dirname(os.path.abspath(__file__)) or '.'

def note(ok, msg):
    results.append(('PASS' if ok else 'FAIL', msg))
    print(('✔' if ok else '✘'), msg)

def focus_canvas(page):
    page.evaluate("document.getElementById('canvasWrap').scrollIntoView({block:'start'})")
    page.wait_for_timeout(150)

def place_points(page, pts, order, loupe_shot=None):
    focus_canvas(page)
    box = page.locator('#stage').bounding_box()
    s = box['width'] / IMG_W
    for i, key in enumerate(order):
        x = box['x'] + pts[key][0]*s
        y = box['y'] + pts[key][1]*s
        if loupe_shot and i == 0:
            page.mouse.move(x, y); page.mouse.down()
            page.mouse.move(x+8, y+6, steps=4)
            page.wait_for_timeout(250)
            page.screenshot(path=loupe_shot)
            page.mouse.move(x, y, steps=3)
            page.mouse.up()
        else:
            page.mouse.click(x, y)
        page.wait_for_timeout(70)

def metric_value(page, name):
    txt = page.locator('#metricsList').inner_text()
    m = re.search(re.escape(name) + r'.*?(\d+,\d)°', txt, re.S)
    return float(m.group(1).replace(',', '.')) if m else None

with sync_playwright() as pw:
    browser = pw.chromium.launch()
    ctx = browser.new_context(viewport={'width':412,'height':915},
                              device_scale_factor=2, accept_downloads=True)
    page = ctx.new_page()
    page.on('pageerror', lambda e: errors.append(f'PAGEERROR: {e}'))
    page.on('console', lambda m: errors.append(f'CONSOLE {m.type}: {m.text}')
            if m.type in ('error',) else None)

    # ---- Start ----
    page.goto(APP); page.wait_for_load_state('networkidle')
    page.screenshot(path=f'{S}/01_start.png')
    note(page.locator('#emptyState').is_visible(), 'App lädt, Startzustand sichtbar')

    # ---- Aufnahme 1 (seitlich, Kopfvorhaltung) ----
    page.fill('#patient', 'Testperson M.')
    page.fill('#sessDate', '2026-06-20')
    page.set_input_files('#fileGal', os.path.join(HERE_L(), 'test_lat1.jpg'))
    page.wait_for_selector('#stage', state='visible')
    page.wait_for_timeout(400)
    page.fill('#sessDate', '2026-06-20')  # Upload setzt Datum auf heute zurück
    place_points(page, LM['LAT1'], ORDER_LAT, loupe_shot=f'{S}/02_lupe.png')
    page.wait_for_timeout(200)
    note('Alle Punkte gesetzt' in page.locator('#guideName').inner_text(),
         'Alle 6 Punkte gesetzt (seitlich)')
    cva1 = metric_value(page, 'CVA')
    note(cva1 is not None and abs(cva1 - 41.8) < 2.0, f'CVA Aufnahme 1 = {cva1}° (erwartet ~41,8°)')
    kw = metric_value(page, 'Kniewinkel')
    note(kw is not None and abs(kw - 176.1) < 2.5, f'Kniewinkel = {kw}° (erwartet ~176°)')
    page.screenshot(path=f'{S}/03_analyse.png', full_page=True)
    page.fill('#notes', 'Erstbefund')
    page.click('#btnAddSession'); page.wait_for_timeout(300)
    note(page.locator('.hist-row').count() == 1, 'Aufnahme 1 in Verlaufsliste')

    # ---- Punkt-Korrektur durch Ziehen testen ----
    focus_canvas(page)
    box = page.locator('#stage').bounding_box(); s = box['width']/IMG_W
    tx, ty = box['x']+LM['LAT1']['tragus'][0]*s, box['y']+LM['LAT1']['tragus'][1]*s
    page.mouse.move(tx, ty); page.mouse.down()
    page.mouse.move(tx-10, ty-8, steps=4); page.mouse.up()
    page.wait_for_timeout(150)
    cva_moved = metric_value(page, 'CVA')
    note(cva_moved is not None and cva_moved != cva1, f'Punkt ziehen ändert Messwert ({cva1}° → {cva_moved}°)')

    # ---- Aufnahme 2 (seitlich, verbessert) ----
    page.set_input_files('#fileGal', os.path.join(HERE_L(), 'test_lat2.jpg'))
    page.wait_for_timeout(400)
    place_points(page, LM['LAT2'], ORDER_LAT)
    page.wait_for_timeout(200)
    cva2 = metric_value(page, 'CVA')
    note(cva2 is not None and abs(cva2 - 58.0) < 2.0, f'CVA Aufnahme 2 = {cva2}° (erwartet ~58,0°)')
    page.fill('#notes', 'Nach 4 Wochen Training')
    page.click('#btnAddSession'); page.wait_for_timeout(300)
    note(page.locator('.hist-row').count() == 2, 'Aufnahme 2 in Verlaufsliste')
    page.screenshot(path=f'{S}/04_verlauf.png', full_page=True)

    # ---- Vergleich ----
    for i in range(2):
        page.locator('#histList input[type=checkbox]').nth(i).check()
    page.click('#btnCompare')
    page.wait_for_selector('#compareCard', state='visible')
    page.wait_for_timeout(700)
    tbl = page.locator('#cmpTable').inner_text()
    note('verbessert' in tbl, 'Vergleichstabelle zeigt "verbessert" für CVA')
    note('20.06.2026' in tbl and '18.07.2026' in tbl, 'Beide Daten in Vergleichstabelle')
    page.screenshot(path=f'{S}/05_vergleich.png', full_page=True)

    # ---- Export / Import (Roundtrip) ----
    with page.expect_download() as dl:
        page.click('#btnExportAll')
    dl.value.save_as(os.path.join(HERE_L(), 'export_test.json'))
    data = json.load(open(os.path.join(HERE_L(), 'export_test.json')))
    note(len(data.get('sessions', [])) == 2, 'Export-Datei enthält 2 Aufnahmen')

    page.goto(APP); page.wait_for_load_state('networkidle')   # frische Sitzung
    page.set_input_files('#fileImport', os.path.join(HERE_L(), 'export_test.json'))
    page.wait_for_timeout(500)
    note(page.locator('.hist-row').count() == 2, 'Import nach Neustart: 2 Aufnahmen wieder da')
    page.locator('.hist-row .hist-main').first.click()        # Eintrag in Editor laden
    page.wait_for_timeout(600)
    cva_re = metric_value(page, 'CVA')
    note(cva_re is not None and abs(cva_re - cva1) < 0.4,
         f'Geladene Aufnahme rechnet identisch (CVA {cva_re}°, gesichert war {cva1}°)')
    page.screenshot(path=f'{S}/06_import_geladen.png', full_page=True)

    # ---- Verlaufsbericht als PDF (Druck-Layout) ----
    for i in range(2):
        page.locator('#histList input[type=checkbox]').nth(i).check()
    page.click('#btnCompare'); page.wait_for_timeout(600)
    page.evaluate('window.print = () => {}')
    page.click('#btnCmpReport')
    page.wait_for_function("document.getElementById('report').innerHTML.length > 500")
    page.wait_for_timeout(300)
    page.pdf(path=os.path.join(HERE_L(), 'verlaufsbericht_test.pdf'), format='A4', print_background=True)
    note(os.path.getsize(os.path.join(HERE_L(), 'verlaufsbericht_test.pdf')) > 20000, 'Verlaufsbericht-PDF erzeugt')

    # ---- Frontal-Ansicht ----
    page.goto(APP); page.wait_for_load_state('networkidle')
    page.click('#segFro')
    page.set_input_files('#fileGal', os.path.join(HERE_L(), 'test_fro.jpg'))
    page.wait_for_timeout(400)
    place_points(page, LM['FRO'], ORDER_FRO)
    page.wait_for_timeout(200)
    sh = metric_value(page, 'Schulterlinie')
    note(sh is not None and abs(sh - 3.8) < 1.5, f'Frontal: Schulterlinie = {sh}° (erwartet ~3,8°)')
    mid = metric_value(page, 'Mittellinie')
    note(mid is not None and mid < 1.0, f'Frontal: Mittellinie = {mid}° (erwartet ~0°)')
    page.screenshot(path=f'{S}/07_frontal.png', full_page=True)

    # ---- Zoom: Pinch, Punkt-Ziehen im Zoom, Reset ----
    page.goto(APP); page.wait_for_load_state('networkidle')
    page.set_input_files('#fileGal', os.path.join(HERE_L(), 'test_lat1.jpg'))
    page.wait_for_timeout(400)
    place_points(page, LM['LAT1'], ORDER_LAT)
    page.wait_for_timeout(200)
    focus_canvas(page)
    page.evaluate('''() => {
      const st = document.getElementById('stage');
      const r = st.getBoundingClientRect();
      const ev = (type, id, x, y) => st.dispatchEvent(new PointerEvent(type,
        {pointerId:id, clientX:x, clientY:y, bubbles:true, pointerType:'touch', isPrimary:id===1}));
      const p = window.__lot.get().pts.tragus;
      const s0 = r.width / 800;
      const cx = r.left + p.x*s0, cy = r.top + p.y*s0;
      ev('pointerdown', 1, cx-30, cy); ev('pointerdown', 2, cx+30, cy);
      for(let i=1; i<=4; i++){
        ev('pointermove', 1, cx-30-i*15, cy); ev('pointermove', 2, cx+30+i*15, cy);
      }
      ev('pointerup', 1, cx-90, cy); ev('pointerup', 2, cx+90, cy);
    }''')
    page.wait_for_timeout(150)
    st = page.evaluate('window.__lot.get()')
    note(2.4 < st['z'] < 3.6, f"Pinch-Zoom: z = {st['z']:.2f} (erwartet ~3)")
    page.screenshot(path=f'{S}/08_zoom.png')
    # Punkt im gezoomten Zustand ziehen: Bildschirmposition über Transform berechnen
    cva_before = metric_value(page, 'CVA')
    pos = page.evaluate('''() => {
      const st = document.getElementById('stage');
      const r = st.getBoundingClientRect();
      const d = window.__lot.get();
      const s2 = (r.width / 800) * d.z;
      const p = d.pts.tragus;
      return {x: r.left + p.x*s2 + d.tx, y: r.top + p.y*s2 + d.ty};
    }''')
    page.mouse.move(pos['x'], pos['y']); page.mouse.down()
    page.mouse.move(pos['x']-14, pos['y']-10, steps=4); page.mouse.up()
    page.wait_for_timeout(200)
    cva_after = metric_value(page, 'CVA')
    note(cva_after is not None and cva_after != cva_before,
         f'Ziehen im Zoom trifft richtig ({cva_before}° → {cva_after}°)')
    page.click('#zoomChip'); page.wait_for_timeout(120)
    st = page.evaluate('window.__lot.get()')
    note(st['z'] == 1 and st['tx'] == 0, 'Zoom-Reset über Chip')

    # ---- KI-Vorschlag (Beta): lädt Modell, liefert Vorschläge oder saubere Meldung ----
    page.goto(APP); page.wait_for_load_state('networkidle')
    page.set_input_files('#fileGal', os.path.join(HERE_L(), 'test_lat1.jpg'))
    page.wait_for_timeout(400)
    note(page.locator('#btnKI').is_visible(), 'KI-Button sichtbar im Platzierungsmodus')
    page.click('#btnKI')
    page.wait_for_function(
        "document.getElementById('kiMsg').hidden === false", timeout=180000)
    st = page.evaluate('window.__lot.get()')
    ki_msg = page.locator('#kiMsg').inner_text()
    n_ki = len(st['placed'])
    note(('erkannt' in ki_msg) or ('vorgeschlagen' in ki_msg),
         f'KI-Pfad sauber abgeschlossen: {n_ki} Punkte · "{ki_msg[:70]}"')
    if n_ki:
        page.screenshot(path=f'{S}/09_ki.png', full_page=True)

    browser.close()

print('\n--- Konsole/Fehler ---')
print('\n'.join(errors) if errors else 'keine JS-Fehler')
fails = [r for r in results if r[0] == 'FAIL']
print(f'\nERGEBNIS: {len(results)-len(fails)}/{len(results)} Tests bestanden')
SRV.terminate()
sys.exit(1 if fails or errors else 0)
