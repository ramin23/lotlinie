"""Synthetische Testfotos: 2x seitlich (vorher/nachher), 1x frontal.
Die Landmarken-Koordinaten sind exakt bekannt -> erwartete Winkel berechenbar."""
from PIL import Image, ImageDraw
import math, json

W, H = 800, 1600
BG = (226, 228, 224); SKIN = (224, 188, 158); SHIRT = (64, 92, 120); PANTS = (52, 56, 62)

def base():
    im = Image.new('RGB', (W, H), BG)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 1500, W, H], fill=(200, 198, 192))  # Boden
    return im, d

def lateral(pts, path):
    im, d = base()
    t, c7, ac, tr, kn, ma = (pts[k] for k in ['tragus','c7','acromion','trochanter','knee','malleolus'])
    # Beine/Rumpf als dicke Linien
    d.line([ma, kn], fill=PANTS, width=52)
    d.line([kn, tr], fill=PANTS, width=58)
    d.line([tr, ac], fill=SHIRT, width=110)
    d.line([ac, c7], fill=SHIRT, width=60)
    # Hals + Kopf (Ohrpunkt = tragus), Blick nach rechts
    head = (t[0] + 12, t[1] - 18)
    d.line([c7, (head[0]-20, head[1]+40)], fill=SKIN, width=44)
    r = 76
    d.ellipse([head[0]-r, head[1]-r, head[0]+r, head[1]+r], fill=SKIN)
    d.ellipse([head[0]+r-14, head[1]-16, head[0]+r+16, head[1]+16], fill=SKIN)  # Nase
    d.ellipse([t[0]-9, t[1]-9, t[0]+9, t[1]+9], fill=(196, 152, 120))            # Ohr
    d.ellipse([head[0]+30, head[1]-30, head[0]+46, head[1]-14], fill=(40,40,40)) # Auge
    # Arm (hängend, leicht vor dem Körper)
    elbow = (ac[0]+30, ac[1]+235); wrist = (ac[0]+18, ac[1]+440)
    d.line([ac, elbow], fill=SHIRT, width=42)
    d.line([elbow, wrist], fill=SKIN, width=34)
    d.ellipse([wrist[0]-22, wrist[1]-10, wrist[0]+22, wrist[1]+50], fill=SKIN)
    # Haare + Mund
    d.pieslice([head[0]-r, head[1]-r-6, head[0]+r, head[1]+r], 180, 330, fill=(72,52,38))
    d.arc([head[0]+18, head[1]+22, head[0]+58, head[1]+52], 20, 150, fill=(120,70,60), width=5)
    # Fuß
    d.line([ma, (ma[0]+90, ma[1]+40)], fill=(90, 70, 60), width=34)
    im.save(path, quality=90)

def frontal(pts, path):
    im, d = base()
    eL,eR,sL,sR,hL,hR,aL,aR = (pts[k] for k in ['eyeL','eyeR','shL','shR','hipL','hipR','ankL','ankR'])
    midE = ((eL[0]+eR[0])//2, (eL[1]+eR[1])//2)
    d.polygon([sL, sR, hR, hL], fill=SHIRT)                     # Rumpf
    d.line([sL, sR], fill=SHIRT, width=70)
    d.line([hL, aL], fill=PANTS, width=60); d.line([hR, aR], fill=PANTS, width=60)
    d.line([(midE[0], midE[1]+60), ((sL[0]+sR[0])//2, (sL[1]+sR[1])//2)], fill=SKIN, width=46)
    r = 88
    d.ellipse([midE[0]-r, midE[1]-r+18, midE[0]+r, midE[1]+r+18], fill=SKIN)     # Kopf
    for e in (eL, eR):
        d.ellipse([e[0]-10, e[1]-10, e[0]+10, e[1]+10], fill=(40,40,40))
    # Arme
    for sp, sgn in ((sL,-1),(sR,1)):
        el = (sp[0]+sgn*55, sp[1]+250); wr = (sp[0]+sgn*70, sp[1]+470)
        d.line([sp, el], fill=SHIRT, width=44)
        d.line([el, wr], fill=SKIN, width=34)
        d.ellipse([wr[0]-22, wr[1]-8, wr[0]+22, wr[1]+50], fill=SKIN)
    # Haare, Nase, Mund
    d.pieslice([midE[0]-r, midE[1]-r-46, midE[0]+r, midE[1]+r+18], 180, 360, fill=(72,52,38))
    d.ellipse([midE[0]-8, midE[1]+34, midE[0]+8, midE[1]+56], fill=(200,160,130))
    d.arc([midE[0]-30, midE[1]+58, midE[0]+30, midE[1]+92], 20, 160, fill=(120,70,60), width=6)
    d.line([aL, (aL[0]-20, aL[1]+40)], fill=(90,70,60), width=30)
    d.line([aR, (aR[0]+20, aR[1]+40)], fill=(90,70,60), width=30)
    im.save(path, quality=90)

LAT1 = dict(tragus=(475,300), c7=(380,385), acromion=(395,400),
            trochanter=(400,750), knee=(412,1100), malleolus=(400,1450))
LAT2 = dict(tragus=(440,297), c7=(385,385), acromion=(398,400),
            trochanter=(400,750), knee=(405,1100), malleolus=(400,1450))
FRO  = dict(eyeL=(365,300), eyeR=(435,303), shL=(280,450), shR=(520,466),
            hipL=(330,770), hipR=(470,764), ankL=(355,1450), ankR=(445,1452))

import os; os.chdir(os.path.dirname(os.path.abspath(__file__)) or '.')
lateral(LAT1, 'test_lat1.jpg')
lateral(LAT2, 'test_lat2.jpg')
frontal(FRO,  'test_fro.jpg')

def cva(p):
    dy = p['c7'][1]-p['tragus'][1]; dx = abs(p['tragus'][0]-p['c7'][0])
    return math.degrees(math.atan2(dy, dx))
print(json.dumps({'CVA1': round(cva(LAT1),1), 'CVA2': round(cva(LAT2),1)}))
with open('landmarks.json','w') as f:
    json.dump({'LAT1':LAT1,'LAT2':LAT2,'FRO':FRO}, f)
